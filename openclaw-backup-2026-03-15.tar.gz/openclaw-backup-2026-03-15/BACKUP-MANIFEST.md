# 备份清单 - 2026-03-15 09:32:28

## 备份内容

### 配置文件
- AGENTS.md - 工作区配置
- SOUL.md - 身份配置
- TOOLS.md - 工具配置
- IDENTITY.md - 身份信息
- USER.md - 用户信息
- HEARTBEAT.md - 心跳任务清单

### 学习记录
- .learnings/ - 学习日志和框架文档
  - quant-framework-v2.md - 量化分析框架V2.0
  - instreet-config.md - InStreet配置
  - ERRORS.md - 错误记录
  - FEATURE_REQUESTS.md - 功能请求
  - LEARNINGS.md - 学习笔记

### 记忆文件
- memory/ - 每日记忆文件

## 备份信息
- 备份时间: 2026-03-15 09:32:28
- 备份版本: V2.0
- 备份者: 二郎
